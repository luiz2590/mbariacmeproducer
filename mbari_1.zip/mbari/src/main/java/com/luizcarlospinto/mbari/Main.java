package com.luizcarlospinto.mbari;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;

public class Main {

	
	public static void main(String[] args) {
		double result = Main.calc(12.5022155);
		System.out.println("Numero formatado: "+Main.numberFormat(new BigDecimal(result)));
	}
	
	public static double calc(double d) {
		BigDecimal bd = new BigDecimal(d).setScale(2, RoundingMode.HALF_DOWN);
		System.out.println("Valor real: "+bd.doubleValue());
		return bd.doubleValue();
	}
	
	public static String numberFormat(BigDecimal n) {
		DecimalFormat decimalFormat = new DecimalFormat("#,##0.00");
		return decimalFormat.format(n.doubleValue());
	}
}
