package com.luizcarlospinto.mbari.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.luizcarlospinto.mbari.domain.ClienteEntity;
import com.luizcarlospinto.mbari.domain.InstalacaoEntity;

public interface InstalacaoRepository extends JpaRepository<InstalacaoEntity, Long>{
	public Optional<InstalacaoEntity> findByCodigo(String codigo);
	public List<InstalacaoEntity> findByCliente(ClienteEntity cliente);
}
