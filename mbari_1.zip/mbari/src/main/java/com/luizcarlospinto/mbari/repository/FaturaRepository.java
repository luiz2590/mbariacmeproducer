package com.luizcarlospinto.mbari.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.luizcarlospinto.mbari.domain.FaturaEntity;
import com.luizcarlospinto.mbari.domain.InstalacaoEntity;

public interface FaturaRepository extends JpaRepository<FaturaEntity, Long>{
	public Optional<FaturaEntity> findByCodigo(String codigo);
	public List<FaturaEntity> findByInstalacao(InstalacaoEntity instalacao);
}
