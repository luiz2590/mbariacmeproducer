package com.luizcarlospinto.mbari.exception;

public class RecursoNotFoundException extends RuntimeException {

	public RecursoNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
