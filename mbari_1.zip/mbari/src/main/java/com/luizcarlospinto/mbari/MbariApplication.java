package com.luizcarlospinto.mbari;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//@EnableSwagger2
@SpringBootApplication
public class MbariApplication {

	public static void main(String[] args) {
		SpringApplication.run(MbariApplication.class, args);
	}

}
